import './Home.css';
const Header = () => {
    return (
        <div className="header">
            <h1 >Daftar Pengunjung</h1>
            <h3 >Stasiun Gubeng</h3>
        </div>
    )
}

export default Header;